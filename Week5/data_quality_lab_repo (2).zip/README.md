# Data Quality & Data Cleaning Lab — E-commerce

## โครงสร้างโปรเจกต์
```
.
├── data/
│   ├── e_commerce_raw.csv        # ข้อมูลดิบ
│   └── customer_reference.csv    # ข้อมูลอ้างอิงลูกค้า
├── notebooks/
│   └── 01_student_lab.ipynb      # Notebook หลัก (รันจากบนลงล่างได้ ไม่ error)
└── outputs/
    └── student_submission/
        ├── e_commerce_clean.csv        # ข้อมูลที่ทำความสะอาดแล้ว + Quality Flags
        └── data_quality_report.csv     # รายงานคุณภาพข้อมูลก่อน–หลัง
```

## วิธีรัน
เปิด `notebooks/01_student_lab.ipynb` ด้วย Jupyter แล้ว Run All (Restart & Run All)
ไฟล์ผลลัพธ์จะถูกสร้างที่ `outputs/student_submission/` โดยอัตโนมัติ

## สรุปผลลัพธ์
| ตัวชี้วัด | ก่อน | หลัง |
|---|---|---|
| จำนวนแถวทั้งหมด | 630 | 612 |
| Customer_Email ที่หายไป | 50 | 0 (เติม placeholder + flag) |
| Province ที่หายไป | 12 | 0 (เติม 'Unknown' + flag) |
| แถวซ้ำทั้งแถว | 18 | 0 |
| Order_Date ที่ต้อง fallback/impute | 88 | ติด flag ไว้ตรวจสอบได้ |
| Quantity ผิดกฎธุรกิจ (นอกช่วง 1–20) | 3 | ติด flag ไว้ ไม่ลบทิ้ง |
| ยอดเงินไม่ตรงสูตร (Accuracy_Flag) | 50 | ติด flag ไว้ ไม่แก้อัตโนมัติสำหรับรายการโปรโมชัน |
| Outlier ที่ถูก Capping (ไม่รวมโปรโมชัน) | 19 | 19 (capped) |
| โหลดข้อมูลล่าช้าเกิน 24 ชม. | 38 | เก็บไว้เป็นข้อมูลประกอบ |
| Order_Status นอกชุดมาตรฐาน | 5 | 5 (mapped/flagged) |
